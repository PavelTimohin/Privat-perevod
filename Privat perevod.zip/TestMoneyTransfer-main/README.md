# TestMoneyTransfer
The **simple automatic test** of transferring money from card to card.<br>
Entering data for transfer<br>

<img width="366" alt="Screenshot 2022-01-30 at 21 57 57" src="https://user-images.githubusercontent.com/97693808/151715426-f87499ef-26b9-4249-a87f-866f4c9a5742.png"><br>
and validation of input data<br>
<img width="1086" alt="Screenshot 2022-01-30 at 21 54 06" src="https://user-images.githubusercontent.com/97693808/151715284-f176e2db-c8e3-4f8d-a53f-660670361fc0.png"><br>
